1 Simply place the crimson theme folder in your themes folder located at users/share/themes, opened as root. You shoud then be able to select Crimson in your Themes setup.
2 You can also select Crimson Windows borders and Crimson Controls.
3 There is a new crimson menu icon in the folder that you just installed. Just right click the menu icon, go to configure, and use the custom icon at /usr/share/themes/Crimson/cinnamon/menu.svg  
4 Optionally, install and enjoy the new crimson wallpapers included.

Linux Mint 18 Cinnamon does away with the lame pointer at the bottom of the main menu and allows menus to attach to the panel, adds left and right side panels, and has improved, more efficient running coding.